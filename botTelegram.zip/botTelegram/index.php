<?php
require 'vendor/autoload.php';
require_once 'dbConfig.php';
use Telegram\Bot\Api;
use Illuminate\Database\Capsule\Manager as Capsule;
// creazione dell'oggetto client
$client = new Api('5892181569:AAGeDj0ug20V1PbYs20dvR8YztGew0oIe6U');
/* per l'attivazione del long polling memorizziamo
l'id dell'ultimo update elaborato */
$last_update_id=0;







while(true){
    // leggiamo gli ultimi update ottenuti
	$response = $client->getUpdates(['offset'=>$last_update_id, 'timeout'=>5]);
	if (count($response)<=0) continue;
	/* per ogni update scaricato restituiamo il messaggio
	sulla stessa chat su cui è stato ricevuto */
	foreach ($response as $r){
        $last_update_id=$r->getUpdateId()+1;
		$message=$r->getMessage();
		$chatId=$message->getChat()->getId();
		$text=$message->getText();
		

        
        $results = Capsule::table('voloprenotato')->get();
        // if (!Capsule::schema()->hasTable('users')) {

        //     Capsule::schema()->create('users', function ($table) {

        //         $table->increments('id');

        //         $table->string('email')->unique();

        //         $table->string('name');

        //         $table->string('surname');

        //         $table->timestamps();

        //     });

        // }
        
        $response = $client->sendMessage([
  			'chat_id' => $chatId,
  			'text' => 'Hai scritto: '.$text.", il volo è".$results[0]->Prezzo
		]);
	}
}
?>